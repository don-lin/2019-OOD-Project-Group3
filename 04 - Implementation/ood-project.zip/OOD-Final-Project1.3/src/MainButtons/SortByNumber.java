package MainButtons;

import javax.swing.JButton;

public class SortByNumber {

	public static JButton button;
}
