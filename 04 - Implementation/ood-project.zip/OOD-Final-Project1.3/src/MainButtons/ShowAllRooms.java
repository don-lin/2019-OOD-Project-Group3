package MainButtons;

import javax.swing.JButton;

public class ShowAllRooms {
	public static JButton button;
}
