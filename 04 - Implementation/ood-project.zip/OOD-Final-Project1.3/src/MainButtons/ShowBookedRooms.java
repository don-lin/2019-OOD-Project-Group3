package MainButtons;

import javax.swing.JButton;

public class ShowBookedRooms {

	public static JButton button;
}
