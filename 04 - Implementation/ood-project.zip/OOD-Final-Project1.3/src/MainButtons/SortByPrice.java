package MainButtons;

import javax.swing.JButton;

public class SortByPrice {

	public static JButton button;
}
