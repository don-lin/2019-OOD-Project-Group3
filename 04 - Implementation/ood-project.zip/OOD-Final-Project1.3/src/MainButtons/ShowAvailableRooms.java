package MainButtons;

import javax.swing.JButton;

public class ShowAvailableRooms {
	public static JButton button;

}
