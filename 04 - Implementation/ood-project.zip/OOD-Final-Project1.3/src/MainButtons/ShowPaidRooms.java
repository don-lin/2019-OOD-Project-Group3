package MainButtons;

import javax.swing.JButton;

public class ShowPaidRooms {
	public static JButton button;

}
