package MainButtons;

import javax.swing.JButton;

public class SortByType {

	public static JButton button;
}
