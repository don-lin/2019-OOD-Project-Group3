package DateManager;

public class GetCurrentDate {

}
